from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

class Election:
    def __init__(self, name):
        self.name = name
        self.candidates = []

    def add_candidate(self, candidate):
        self.candidates.append(candidate)

import os

class Candidate:
    def __init__(self, name):
        self.name = name
        self.photo = self.load_photo()

    def load_photo(self):
        candidates_dir = os.path.join(os.getcwd(), 'static', 'candidates')
        photo_path = os.path.join(candidates_dir, f"{self.name.lower()}.jpg")
        if os.path.exists(photo_path):
            return f"candidates/{self.name.lower()}.jpg"
        else:
            return None

    def receive_vote(self):
        self.votes += 1

class Voter:
    def __init__(self, voter_id):
        self.voter_id = voter_id
        self.has_voted = False

    def cast_vote(self, candidate):
        if not self.has_voted:
            candidate.receive_vote()
            self.has_voted = True
            return True
        return False

class VotingSystem:
    def __init__(self):
        self.voters = []
        self.election = None

    def initiate_election(self, name):
        self.election = Election(name)

    def submit_candidates(self, candidate1_name, candidate1_photo, candidate2_name, candidate2_photo):
        candidate1 = Candidate(candidate1_name, candidate1_photo)
        candidate2 = Candidate(candidate2_name, candidate2_photo)
        self.election.add_candidate(candidate1)
        self.election.add_candidate(candidate2)
        return candidate1, candidate2

    def register_voters(self, voter_ids):
        for voter_id in voter_ids:
            self.voters.append(Voter(voter_id))

voting_system = VotingSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/initiate_election', methods=['POST'])
def initiate_election():
    election_name = request.form['election_name']
    voting_system.initiate_election(election_name)
    return redirect(url_for('election'))

@app.route('/election')
def election():
    if not voting_system.election:
        return redirect(url_for('index'))
    return render_template('election.html', election=voting_system.election)

@app.route('/submit_candidates', methods=['POST'])
def submit_candidates():
    candidate1_name = request.form['candidate1_name']
    candidate1 = Candidate(candidate1_name)
    
    candidate2_name = request.form['candidate2_name']
    candidate2 = Candidate(candidate2_name)

    voting_system.submit_candidates(candidate1, candidate2)

    voter_ids = [1, 2, 3, 4, 5]
    voting_system.register_voters(voter_ids)

    return redirect(url_for('cast_vote'))



@app.route('/cast_vote')
def cast_vote():
    if not voting_system.election:
        return redirect(url_for('index'))
    candidates = voting_system.election.candidates
    return render_template('cast_vote.html', candidates=candidates)

@app.route('/submit_vote', methods=['POST'])
def submit_vote():
    voter_id = int(request.form['voter_id'])
    candidate_id = int(request.form['candidate'])
    voter = next((v for v in voting_system.voters if v.voter_id == voter_id), None)
    if voter and not voter.has_voted:
        voter.cast_vote(voting_system.election.candidates[candidate_id])
    return redirect(url_for('cast_vote'))

if __name__ == '__main__':
    app.run(debug=True)
